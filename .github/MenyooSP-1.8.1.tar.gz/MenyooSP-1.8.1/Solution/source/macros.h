/*
* Menyoo PC - Grand Theft Auto V single-player trainer mod
* Copyright (C) 2019  MAFINS
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/
#pragma once

//#pragma comment(lib, "$(SolutionDir)\external\ScriptHookV.lib")

#pragma warning(disable : 4244 4305) // double <-> float conversions

#define _CRT_SECURE_NO_WARNINGS

// version
#define MENYOO_CURRENT_VER_ "1.8.1"

#define GAME_PLAYERCOUNT 30








