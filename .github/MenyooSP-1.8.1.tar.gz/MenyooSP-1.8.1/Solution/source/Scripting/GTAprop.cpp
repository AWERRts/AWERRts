#include "GTAprop.h"

//#include "..\macros.h"


GTAprop::GTAprop()
	: GTAentity()
{
}
GTAprop::GTAprop(int handle)
	: GTAentity(handle)
{
}
GTAprop::GTAprop(const GTAentity& obj)
	: GTAentity(obj)
{
}


