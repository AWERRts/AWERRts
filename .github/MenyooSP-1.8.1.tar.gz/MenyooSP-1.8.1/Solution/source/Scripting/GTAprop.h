#pragma once

#include "GTAentity.h"


class GTAprop : public GTAentity
{
public:
	
	GTAprop();
	GTAprop(int handle);
	GTAprop(const GTAentity& obj);

};


